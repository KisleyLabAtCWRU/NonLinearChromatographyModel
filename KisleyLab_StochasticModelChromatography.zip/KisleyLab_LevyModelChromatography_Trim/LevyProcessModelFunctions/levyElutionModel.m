%% Pasti based Levy representation modeling of elution
% RMN, KL, 04/24/25
function peak = levyElutionModel(dwells,dt,numFrames,rm,np)

%Data input
%dt - frame time in ms;
frame_no=numFrames;%total number of frames;
AllDwell=dwells;%vector of observed dwell times

% create frequency vector (i.e. histogram y values in %s)
ts = (dt.*[1:frame_no]);%vector of all possible observed times, bin locations in hist

n=hist(AllDwell,ts); %histogram with bin size = 1 frame
totes=numel(AllDwell); %total number of observed events
f=(n./totes); %convert to frequency

mW = sum(ts.*f)/sum(f);%weighted mean of ts;

ns = numel(ts);%rm*3;%rm*3; 
w = ((0:np)*pi)/(np*dt);

% %Calculate characteristic function
for k=1:np+1  
    sumterms=[];
    for m=1:ns
        sumterms(m)=(exp(sqrt(-1)*w(k)*ts(m))-1)*f(m);%in minutes
%         sumterms(m)=exp((sqrt(-1)*((k*pi)./(np*dt))*ts(m))-1)*f(m);
    end   
    expsum=sum(sumterms);  
    cf(k) = exp(rm*expsum);
end

conjcf = fliplr(conj(cf));
conjcf = conjcf(2:np);

fullcf = [cf,conjcf];

%Calculate Fourier transform and scale
peak = real(ifft(fullcf))*sqrt(2*np);
peak=fliplr(peak);

% dTmodel = dt/1000;
% peak_Times = dTmodel:dTmodel:numel(peak)*dTmodel;
% 
% plot(peak_Times,peak,'.-');

end