%% Error Function for Pasti Et al elution modeling
%Ricardo MN, Kisley Lab, 08/2025
function average_error = LevyModelElution_error_vShape(expData,SMdwell,dt,numFrames,Weights,x);
%Output:
% average_error= net summed percent error between the model and experiment

%Input: 
% expData = [Signal;Time (minutes)]; %experimental elution data
% dt = time resolution in single-molecule measurements
% numFrames = how many frames per single-molecule measurement
% numFrames defines the upper limit of observabel adsorption times
% Weights = [W1,W2,W3], weights for fitting [asymmtery, width, time];
% x = value of r_m for model; avg. SM adsorptions.

norm_ExpPeak = expData(1,:)./max(expData(1,:));
sec_ExpTime = expData(2,:).*60;% mins to sec
[peakExp,max_indExp]=max(norm_ExpPeak);

norm_PrePeak = norm_ExpPeak(1:max_indExp);%only data before the elution peak - to get void peak
[voidExp,min_indExp]=min(norm_PrePeak);
tR = sec_ExpTime(max_indExp);tVoid = sec_ExpTime(min_indExp);

rm_test = x(1);%(1); 
np_test = rm_test*2;%x(2);%

if np_test < 500;
    np_test = 500;
end

if nargin<5
    rm_test=(tR-tVoid)/mean(SMdwell/1000); % tS/Ts; tS = tR-tvoid; Ts = average dwell; position based fitting
end

%model_vars = [rm, np]; %average adsorptions and sampling points

if np_test/rm_test <1.6 %&& rm_test/np_test <(1/0.05) && max(isfinite(peak))==0
    average_error = 1000;%percent error i.e. infinity
    return 
end

peak = levyElutionModel(SMdwell,dt,numFrames,rm_test,np_test);

%check rm and np choices yield real, finite, and non-undersample results


norm_peak = peak./max(peak);

[m,max_ind]=max(norm_peak);
dTmodel = dt/(1000);%ms to seconds
peak_Times = dTmodel:dTmodel:numel(norm_peak)*dTmodel;
tS_model = peak_Times(max_ind);

%define peak asymetric widths for model data
asym01=[0];%for asymetries
for i=1:numel(norm_peak)
    if round(norm_peak(i),1)==round(0.1+min(norm_peak),1);
        asym01=[asym01,i];
    end
end

diff_peak =[];edge=[];
for i=2:numel(asym01)
    diff_peak(i)=max_ind-asym01(i);
    if diff_peak(i)<0 && diff_peak(i-1)>0
        edge=[asym01(i-1),asym01(i)];
    end   
end

if length(edge)<2
    average_error = 1000;%percent error i.e. infinity
    return 
end

b_model=abs(max_ind-edge(2))*dTmodel;
a_model=abs(max_ind-edge(1))*dTmodel;
asym_model = b_model/a_model;
wR_model = (a_model+b_model);%*dTmodel;%disp(strcat(num2str(wR)," mins"));


%from expt data
average_error = [];
norm_ExpPeak = norm_ExpPeak(min_indExp:end);
sec_ExpTime = sec_ExpTime(min_indExp:end)-tVoid;
[mP, mInd] = max(norm_ExpPeak);
tS_exp = sec_ExpTime(mInd);

% figure(1); hold on;
% plot(sec_ExpTime-sec_ExpTime(mInd), norm_ExpPeak);
% plot(peak_Times-peak_Times(max_ind),norm_peak);

%define peak asymetric widths for expt data
asym01=[0];%for asymetries
for i=2:numel(norm_ExpPeak)
    if round(round(norm_ExpPeak(i),2),1)==round(0.1+min(norm_ExpPeak),1) || round((norm_ExpPeak(i)+norm_ExpPeak(i-1))/2,1)==round(0.1+min(norm_ExpPeak),1);
        asym01=[asym01,i];
    end
end
diff_peak =[];edge=[];
for i=2:numel(asym01)
    diff_peak(i)=mInd-asym01(i);
    if diff_peak(i)<0 && diff_peak(i-1)>0
        edge=[asym01(i-1),asym01(i)];
    end   
end
b_exp=abs(sec_ExpTime(mInd)-sec_ExpTime(edge(2)));
a_exp=abs(sec_ExpTime(mInd)-sec_ExpTime(edge(1)));
asym_exp = b_exp/a_exp;
wR_exp = (a_exp+b_exp);%disp(strcat(num2str(wR)," mins"));

% for i=1:length(sec_ExpTime)
%     [mT, minInd_T] = min(abs(peak_Times - sec_ExpTime(i)));
%     eRR = abs(norm_ExpPeak(i)-norm_peak(minInd_T))/abs(norm_ExpPeak(i));
%     average_error = [average_error,eRR*100];% percent error
% end

% figure(2); hold on
% plot(1, asym_exp, 'bo');
% plot(1,asym_model, '*');
% plot(1, wR_exp, 'bo');
% plot(1,wR_model, '*');


%average_error = mean(average_error);
asym_error = abs((asym_exp-asym_model)/asym_exp);
wR_error = abs((wR_exp-wR_model)/wR_exp);
time_error = abs((tS_exp-tS_model)/tS_exp);


average_error = sqrt(Weights(1)*time_error^2 + Weights(2)*wR_error^2 + Weights(3)*asym_error^2);%asym_error^2 + wR_error^2)%); %sqrt(asym_error^2+wR_error^2);time_error^2;asym_error^2+
end