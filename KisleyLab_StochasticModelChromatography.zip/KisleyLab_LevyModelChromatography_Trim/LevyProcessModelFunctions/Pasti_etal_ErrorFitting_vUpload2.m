%% Stochastic chromatography - SM-Bulk
% Ricardo MN, 2025, Kisley Lab
% Matlab 2024a
% based on Pasti, et al., doi: 10.1021/AC0482514
% Generates a chromatogram with either an error minimization fitted or fixed value of average
% number of adsorptions (rm) 

% IMPORTANT: Run code by sections instead of all at once

%%  (Optional) Load Single Molecule adsorption data from LRG single particles identify (_analyzed.mat) file
clear;close all;clc

%User defined parameters
dt=30; % avg. time between frames in ms (exposure + clean time);
numFrames=2000; %total number of frames per collection - for possible observed times; for each file select below
Weights = [0,1,1];% [Elution time, Width, Asymmetry] - error minimization weight values
runMinimization = 1; %if '1' runs error minimizer; if '0' defaults to theoretical rm value

mainFolderlocat = 'Y:\RicardoMN\HPLCvSM\LevyModel\UploadVersions\KisleyLab_LevyModelChromatography'
%---------------------
startloc='Y:\RicardoMN\HPLCvSM\LevyModel\UploadVersions\KisleyLab_LevyModelChromatography\UsedImageData\';% Initial folder location to look at
numFiles=1; %how many files you want to open
multiSelect = 'true'; %set to true if selecting multiple files in the exact same folder (no subfolders)

% cd(startloc);

fileNames = "";% stuctures to store files information
filePaths = "";

if strcmp(multiSelect,'true')==0
    for i=1:numFiles
        [file, path] = uigetfile('_analyzed.mat')
        
        fileNames = [fileNames, file];
        filePaths = [filePaths, path];
    end
else
    folder = uigetdir(startloc);
    fileList = dir(fullfile(folder,'**','*_analyzed.mat'));
    
    %re-run section if editing filelist
    numFiles = size(fileList,1);
    fileNames = "";% stuctures to store files information
    filePaths = "";
    for i=1:numFiles
        fileNames = [fileNames,fileList(i).name];
        filePaths = [filePaths,strcat(fileList(i).folder,'\')];
    end

end

disp('All Files Selected')

%% (Optional) Make Cumulative Dwell time distribution file
% Run only if one is not already made

% fullDwell = [];
% for i=2:numel(fileNames)
%     load(strcat(strcat(filePaths(i),fileNames(i))));
%     fullDwell = [fullDwell,Ensemble.Dwell];
% end
% save(strcat(filePaths(numel(fileNames)),"_analyzed_FullDwell.mat"),'fullDwell');
% disp('Saved Full Dwell');

%load this file in the step above

%%  (Optional) Make Cumulative Assoc time distribution file
% Run only if one is not already made

% fullAssoc = [];
% for i=2:numel(fileNames)
%     load(strcat(strcat(filePaths(i),fileNames(i))));
%     fullAssoc = [fullAssoc,Ensemble.Assoc];
% end
% save(strcat(filePaths(numel(fileNames)),"_analyzed_FullAssoc.mat"),'fullAssoc');
% disp('Saved Full Assoc');

%%  HPLC data - load
%select the HPLC data that you are fitting to (if applicable)
close all;clc;
T = readtable(strcat(mainFolderlocat,'\HPLC_UsedData\HPLC_Ctrl_AllFR.xlsx'),'HeaderLines',0,'ReadVariableNames',true); %HPLC data to campare - Excel table
fRates = [50];%uL/min%linear velocities estimated, cm/min

expSignal = table2array(T(:,8)); %change index here to match desired dataset of the HPLC data (defaults to the 0.5mL/min example data)
expTimes = table2array(T(:,1));
expData = [transpose(expSignal);transpose(expTimes)];

%%  Run error minimization and generate chromatograms
close all;clc;warning off;

addpath(strcat(mainFolderlocat,'\LevyProcessModelFunctions'))

[grad,im]=colorGradient([0 0 0],[0 0 1],4); %color gradient generator
peakStore = struct([]); %stored chromatograms and shape parameters
%runMinimization = 0; %bypass

for rZ=2:numel(fileNames); 

% Load input data
    e.filename=fileNames(rZ);
    e.codedir= filePaths(rZ);
    e.path= filePaths(rZ);
    addpath(e.path); 
    load(strcat(e.path,e.filename));

% HPLC data
norm_ExpPeak = expData(1,:)./max(expData(1,:));
sec_ExpTime = expData(2,:).*60;% mins to sec
[peakExp,max_indExp]=max(norm_ExpPeak);

norm_PrePeak = norm_ExpPeak(1:max_indExp);%only data before the elution peak - to get void peak
[voidExp,min_indExp]=min(norm_PrePeak);

mU = mean(norm_PrePeak,'omitnan');

tR = sec_ExpTime(max_indExp);
tVoid = sec_ExpTime(min_indExp);

%from expt data
average_error = [];
norm_ExpPeak = norm_ExpPeak(min_indExp:end);
sec_ExpTime = sec_ExpTime(min_indExp:end)-tVoid;
[mP, mInd] = max(norm_ExpPeak);
tS_exp = sec_ExpTime(mInd);


%define peak asymetric widths for expt data
asym01=[];%for asymetries
for i=1:numel(norm_ExpPeak)
    asym01 =find(norm_ExpPeak >= 0.1);
end

b_exp=abs(sec_ExpTime(mInd)-sec_ExpTime(asym01(end)));
a_exp=abs(sec_ExpTime(mInd)-sec_ExpTime(asym01(1)));
asym_exp = b_exp/a_exp;
wR_exp = (a_exp+b_exp);%disp(strcat(num2str(wR)," mins"));


if  exist('fullDwell', 'var')
SMdwell= fullDwell;%load('12_16_AllDwellTimes.mat'); %vector of observed dwell times
else
SMdwell = Ensemble.Dwell;
end


% Run fitting error minimization
x0 = (tR-tVoid)/mean(SMdwell/1000);%use theory value as initial guess;

if runMinimization == 1
    fun = @(x) LevyModelElution_error_vUpload(expData,SMdwell,dt,numFrames,Weights,x);
    opts = optimset('MaxIter', 100, 'MaxFunEvals', 100);
    %opts = optimset('PlotFcns',@optimplotval);
    [x,fval] = fminsearch(fun,x0,opts);
else 
    x = x0; fval = LevyModelElution_error_vUpload(expData,SMdwell,dt,numFrames,Weights,x);
end
 

if length(x)<2
    fitNP=x(1)*2;%x(2);%np;% number of point - model fitting
    if x(1)<1000;
        fitNP = fitNP+500;
    end
else
    fitNP=x(2);%np;% number of point - model fitting
end

% Plot fit results
norm_ExpPeak = expData(1,:)./max(expData(1,:));
sec_ExpTime = expData(2,:).*60;% mins to sec
[peakExp,max_indExp]=max(norm_ExpPeak);

norm_PrePeak = norm_ExpPeak(1:max_indExp);%only data before the elution peak - to get void peak
[voidExp,min_indExp]=min(norm_PrePeak);
tR = sec_ExpTime(max_indExp);tVoid = sec_ExpTime(min_indExp);
sec_ExpTime = sec_ExpTime-tVoid;

 rm=x(1);%(tR-tVoid)./(mean(SMdwell)/1000); % tS/Ts; tS = tR-tvoid; Ts = average dwell; position based fitting
 %rm = sort(rm);
 % rKeep = prctile(unique(rm),[40 80],"all");
 % rm = rm(rm<max(rKeep)||rm>min(rKeep));

 peak = levyElutionModel(SMdwell,dt,numFrames,rm,fitNP);
 norm_peak = peak./max(peak);
 dTmodel = dt/(1000);%ms to seconds %(sec_ExpTime(end))/numel(norm_peak);
 peak_Times = dTmodel:dTmodel:numel(norm_peak)*dTmodel;
 [m,max_ind]=max(norm_peak);


 peakStore(rZ-1).Model = transpose([peak_Times./60; peak; norm_peak;(peak_Times-peak_Times(max_ind))./60]);%in minutes scale
 peakStore(rZ-1).LinearVel = fRates(rZ-1);
 peakStore(rZ-1).dTmodel = dTmodel/60; %time step between data points
  peakStore(rZ-1).fitError = fval;
 peakStore(rZ-1).rmFit = rm; %value used or fitted to
 peakStore(rZ-1).rmTheory = x0;
 peakStore(rZ-1).meanDwell = mean(SMdwell);% in units of ms


  figure(1);hold on; 
 % plot(peak_Times-peak_Times(max_ind),norm_peak,'.--','DisplayName','Model Fit');
 % plot(sec_ExpTime(min_indExp:end)-sec_ExpTime(max_indExp),norm_ExpPeak(min_indExp:end),'-','DisplayName','Experimental');

 if rZ==2
    tiledlayout(3,2);hold on;pbaspect([1.618 1 1]);
    ax1 = nexttile(1);hold on;plot(sec_ExpTime(min_indExp:end),norm_ExpPeak(min_indExp:end),'ro-','DisplayName','Experimental');
    title('Model Peak Results');
    xlabel('Time (sec)');ylabel('Normalized Signal (AU)','FontSize',16,'FontWeight','bold');
    ax = gca;ax.Box = 'on';pbaspect([1.618 1 1]);

    ax2 = nexttile(2);hold on;plot(sec_ExpTime(min_indExp:end)-sec_ExpTime(max_indExp),norm_ExpPeak(min_indExp:end),'ro-','DisplayName','Experimental');
    title('Model Peak Results');
    xlabel('Centered Time,\itt-t_R \rm\bf(sec)','FontSize',16,'FontWeight','bold');ylabel('Normalized Signal (AU)','FontSize',16,'FontWeight','bold');
    ax = gca;ax.Box = 'on';pbaspect([1.618 1 1]);
 end


 nexttile(1);hold on;plot(peak_Times,norm_peak,'.-','Color',grad(rZ-1,:),'DisplayName',strcat("Model Fit ",num2str(fRates(rZ-1))," \muL/min"));
 legend()
 nexttile(2);hold on;plot(peak_Times-peak_Times(max_ind),norm_peak,'.-','Color',grad(rZ-1,:),'DisplayName',strcat("Model Fit ",num2str(fRates(rZ-1))," \muL/min"));
 legend()


% Calculate peak asymmetries, etc
norm_peak=peak./max(peak);

asym01=[0];%for asymetries
for i=1:numel(norm_peak)
    if round(norm_peak(i),1)==round(0.1+min(norm_peak),1);
        asym01=[asym01,i];
    end
end
[m,max_ind]=max(norm_peak);
diff_peak =[];edge=[];
for i=2:numel(asym01)
    diff_peak(i)=max_ind-asym01(i);
    if diff_peak(i)<0 && diff_peak(i-1)>0
        edge=[asym01(i-1),asym01(i)];
    end   
end

% Defined quality parameters
b=abs(max_ind-edge(2))*dTmodel;
a=abs(max_ind-edge(1))*dTmodel;
wR = (a+b);%disp(strcat(num2str(wR)," mins"));
%Hplate= 50*((wR)^2)/(5.54*((max_ind*dTmodel)^2));%

%Hplate = 50*41.7*((tR/(wR))^2)/((b/a)+1.25); %EGM Method (Exponentially
%Modified Gaussian)

 % text((edge(2))*dTmodel,0.6, strcat("Fit np = ",num2str(fitNP)));
 % text((edge(2))*dTmodel,0.4, strcat("Fit rm = ",num2str(rm)));
peakStore(rZ-1).asym = b/a;
peakStore(rZ-1).wR = wR;
peakStore(rZ-1).tR = peak_Times(max_ind);
peakStore(rZ-1).pMax = max(peak);

end

disp('Completed');

%%  (Optional) For easily exporting data to tabulated sheets format
close all;clc;

ExportArray = [rm, x0, mean(SMdwell), b/a, wR, peak_Times(max_ind), asym_exp, wR_exp, tS_exp];
Export2 = transpose([sec_ExpTime(min_indExp:end);sec_ExpTime(min_indExp:end)-sec_ExpTime(max_indExp);norm_ExpPeak(min_indExp:end)]);
Export3 = transpose([peak_Times;peak_Times-peak_Times(max_ind);norm_peak]);